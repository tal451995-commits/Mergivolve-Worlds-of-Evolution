// Headless Chromium integration test of the DEV COPY (served over http). Usage: node tests/browser-test.js  (needs `playwright` + chromium)
const {chromium}=require('playwright'),assert=require('assert'),fs=require('fs');
const URL=process.env.URL||'http://localhost:8123/merge-game.html',KEY='mergivolve-merge-prototype-v1',OUT=process.env.SHOTS||'/tmp/shots';fs.mkdirSync(OUT,{recursive:true});
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:2,isMobile:true,hasTouch:false});const page=await ctx.newPage();
 const bad=[],errs=[];page.on('response',r=>{if(r.status()>=400)bad.push(r.status()+' '+r.url())});page.on('requestfailed',r=>{if(!/^http:\/\/localhost/.test(r.url()))console.log('NOTE external request failed (sandbox has no internet):',r.url().slice(0,60))});page.on('pageerror',e=>errs.push(String(e)));page.on('console',m=>{if(m.type()==='error'&&!/ERR_NAME_NOT_RESOLVED/.test(m.text()))errs.push(m.text())});
 let n=0;const ok=m=>{n++;console.log('PASS',m)};
 const empty=()=>Array(25).fill(null);const wild=(l,sp,st,x)=>({type:'wild',level:l,...(sp?{speciesId:sp,familyId:sp,evolutionStage:st}:{}),...(x||{})});
 const load=async(board,extra)=>{await page.goto(URL);await page.evaluate(([k,s])=>localStorage.setItem(k,JSON.stringify(s)),[KEY,{board,coins:800,gems:12,xp:0,merges:0,...(extra||{})}]);await page.reload();await page.waitForSelector('.board-item');await page.waitForTimeout(250)};
 const st=()=>page.evaluate(()=>JSON.parse(JSON.stringify(window.__mergivolveDev.state)));const tap=i=>page.locator(`.cell[data-index="${i}"]`).click();
 const merge=async(a,c)=>{await tap(a);await page.waitForTimeout(120);await tap(c);await page.waitForTimeout(1300)};
 // A. clean load
 await page.goto(URL);await page.waitForSelector('.board-item');
 assert.equal(await page.evaluate(()=>window.__mergivolveDev.EVO_IDX.count),142);ok('dev copy loads, catalog 142 via evolution layer');
 // B/C/D. egg -> hatch -> album
 let b0=empty();b0[12]={type:'gen',level:1};b0[6]=wild(5);b0[8]=wild(5);await load(b0);
 await merge(6,8);let s=await st();let egg=s.board[8];assert.ok(egg&&egg.level===6&&egg.egg===true&&egg.speciesId&&egg.evolutionStage===1&&s.board[6]===null);ok('merge L5+L5 -> L6 EGG with species '+egg.speciesId);
 await page.waitForTimeout(200);assert.equal(await page.locator('.board-item[data-index="8"] .board-egg').count(),1);await page.screenshot({path:OUT+'/1-board-egg.png'});ok('egg is drawn (not the level art)');
 assert.equal(Object.keys(s.album.species).length,0);ok('no discovery recorded before the egg hatches');
 const disc=[];await page.evaluate(()=>{window.__d=[];addEventListener('mergivolve:discovery',e=>window.__d.push(e.detail))});
 await tap(8);await page.waitForSelector('.mfx-ov');await page.waitForTimeout(1300);await page.screenshot({path:OUT+'/2-hatch-cracking.png'});await page.waitForSelector('.mfx-ov.open',{timeout:7000});await page.waitForTimeout(1500);await page.screenshot({path:OUT+'/3-hatch-reveal.png'});
 ok('hatch cinematic plays (wobble, cracks, split, reveal)');
 await page.locator('.mfx-ov').click();await page.waitForTimeout(700);await page.locator('.mfx-ov').click({force:true}).catch(()=>{});await page.waitForTimeout(600);assert.equal(await page.locator('.mfx-ov').count(),0);ok('overlay closes on tap');
 s=await st();const hid=egg.speciesId,sp=await page.evaluate(i=>window.__mergivolveDev.EVO_IDX.byId[i],hid);const h=s.board[8];assert.ok(!h.egg&&h.speciesId===hid&&h.evolutionStage===(sp.evolutionStages[0]==='egg'?2:1));assert.ok(s.album.species[hid]);assert.equal(await page.evaluate(()=>window.__d.length),1);ok('hatched: stage '+h.evolutionStage+', discovered once ('+sp.nameEn+')');
 await page.reload();await page.waitForSelector('.board-item');s=await st();assert.equal(Object.keys(s.album.species).length,1);assert.deepEqual(s.album.claimed,{});ok('reload keeps album, no duplicate discovery, no reward auto-claimed');
 await page.screenshot({path:OUT+'/4-board-after-hatch.png'});
 // E. chains
 for(const [id,start,count] of [['oni',1,4],['forest_dragon',2,4]]){let board=empty();board[12]={type:'gen',level:1};const seq=[];let stage=start;
  for(const L of [6,7,8]){board=empty();board[12]={type:'gen',level:1};board[6]=wild(L,id,stage);board[8]=wild(L,id,stage);await load(board);const c0=(await st()).coins;await merge(6,8);s=await st();const r=s.board[8];assert.equal(r.speciesId,id);seq.push(L<8?r.level+':s'+r.evolutionStage:'asc:s'+r.evolutionStage);assert.ok(!r.egg);stage=r.evolutionStage;if(L===8)assert.ok(s.coins>c0)}
  assert.equal(stage,count);assert.equal(s.album.species[id].maxStage,count);ok(id+' chain '+seq.join(' -> ')+' (same species, ends at final stage '+count+')')}
 // F. cross species
 let bf=empty();bf[6]=wild(7,'oni',2);bf[8]=wild(7,'tengu',2);await load(bf);await merge(6,8);s=await st();assert.equal(s.board[6].speciesId,'oni');assert.equal(s.board[8].speciesId,'tengu');ok('cross-species merge refused, both items intact');
 // G. old save
 let bg=empty();bg[6]=wild(7,'forest_dragon',2);bg[8]=wild(7,'oni',2);await load(bg);s=await st();assert.equal(s.board[6].evolutionStage,3);assert.equal(s.board[8].evolutionStage,2);assert.ok(s.album.species.forest_dragon&&s.album.species.oni);assert.equal(s.coins,800);ok('old-format save loads: egg-start item re-staged, standard untouched, coins kept, album back-filled');
 await page.screenshot({path:OUT+'/5-board-stage-chips.png'});
 // H. hatch demo page
 await page.goto(URL.replace('merge-game.html','hatch-demo.html'));await page.click('#go');await page.waitForSelector('.mfx-ov.open',{timeout:7000});await page.waitForTimeout(1600);await page.screenshot({path:OUT+'/6-hatch-demo.png'});ok('hatch-demo.html plays');
 assert.deepEqual(bad,[],'HTTP errors: '+bad.join(', '));ok('no 404/HTTP errors on any asset request');assert.deepEqual(errs,[],'console/page errors: '+errs.join(' | '));ok('no JavaScript errors');
 console.log('\n'+n+' browser checks passed; screenshots in '+OUT);await b.close()})().catch(e=>{console.error('FAIL',e.message);process.exit(1)});
