Clear Balance — קובצי PWA לגרסה הנוכחית באתר

חשוב: הקובץ HTML שצורף לשיחה אינו זהה לגרסה שמתפרסמת כרגע ב-GitHub Pages. לכן החבילה הזו לא כוללת index.html, כדי לא להחליף בטעות את העיצוב/הגרסה הנוכחיים.

מה לעשות:
1. פתחו את מאגר GitHub: tal451995-commits/Clear-Balance.
2. העלו לתיקיית השורש את `manifest.webmanifest`, `sw.js` ואת תיקיית `icons`.
3. פתחו את `index.html` הקיים במאגר, ובמצב עריכה הוסיפו את הקישורים שמופיעים בראש הקובץ `PATCH-TO-ADD.txt` בתוך `<head>`.
4. הוסיפו את קטע ה-script השני מ-`PATCH-TO-ADD.txt` לפני `</body>`.
5. שמרו Commit והמתינו לפרסום GitHub Pages.

ההוספות לא משנות את מבנה המסך, הצבעים או ה-CSS. הן מוסיפות manifest תקין, אייקוני PNG אמיתיים, ורישום Service Worker מאותו מקור.

אחרי פרסום:
- Android / Chrome: פתחו את האתר, לחצו ⋮ ובחרו "התקנת אפליקציה" או "הוספה למסך הבית".
- iPhone / Safari: פתחו את האתר ב-Safari → שיתוף → "הוסף למסך הבית".

אם Chrome עדיין מציג הודעה ישנה, סגרו את הטאב, פתחו מחדש, ורעננו/נקו נתוני אתר עבור הדומיין לפני ניסיון נוסף. בדקו שהכתובות הבאות נטענות:
`/Clear-Balance/manifest.webmanifest`
`/Clear-Balance/sw.js`
`/Clear-Balance/icons/icon-192.png`
